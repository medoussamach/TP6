package tp6;

public class AssietteCarree extends Assiette {
	public double cote;
	public AssietteCarree(int anneefab,double cote) {
		super(anneefab);
		this.cote=cote;
}
	public double CalculSurface() {
		return cote*cote;
	}
	public double CalculValeur() {
		if((2024-anneefab)<50) {
			return 0;
		}
		else {
			return (2024-anneefab-50)*5;
		}
	}
}
