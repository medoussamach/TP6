package tp6;

public class AssietteRonde extends Assiette {
	public double rayon;
	public AssietteRonde(int anneefab,double rayon) {
		super(anneefab);
		this.rayon=rayon;
}
	public double CalculSurface() {
		return 3.14*rayon*rayon;
	}
	
	
}
