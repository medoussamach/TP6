package tp6;

public class Cuillere extends Ustensile {
	public double longueur;
	public Cuillere(int anneefab,double longueur) {
		super(anneefab);
		this.longueur=longueur;
	}

}
