package tp6;

public abstract class Ustensile {
	protected int anneefab;
	public Ustensile(int anneefab) {
		this.anneefab=anneefab;
	}
	public double CalculValeur() {
	if((2024-anneefab)>50) {
		return 2024-anneefab-50;	
	}else {
		return 0;
	}
}
}