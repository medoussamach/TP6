package tp6;

public abstract class Assiette extends Ustensile {
	public Assiette(int anneefab) {
		super(anneefab);
		this.anneefab=anneefab;
	}
	public abstract double CalculSurface();
}
